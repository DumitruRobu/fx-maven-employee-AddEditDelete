package it.step.controller;
import it.step.model.Person;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class MainSceneController implements Initializable {

    public TableColumn<Person, Integer> idCol;
    public TableColumn<Person, String> numeCol;
    public TableColumn<Person, String> prenumeCol;
    public TableColumn<Person, String> emailCol;
    public TableColumn<Person, LocalDate> dataCol;

    public TableView<Person> table;


    public void onAdd(ActionEvent event){
        table.getItems().add(new Person(4, "Janice", "Russell", "31@mail.ru", LocalDate.of(1999, 9, 20)));
    }

    public void onDelete(ActionEvent event){
        //getselected index
        int idx = table.getSelectionModel().getSelectedIndex();
        if (idx!=-1){
            table.getItems().remove(idx);
        }
        //delete selected index
    }

    public void onEdit(ActionEvent event){
        int idx = table.getSelectionModel().getSelectedIndex();
        if (idx!=-1){
            table.getItems().get(idx).setId(999);
            table.getItems().get(idx).setName("edited name");
            table.getItems().get(idx).setSurname("edited surname");
            table.getItems().get(idx).setEmail("edited email");
            table.getItems().get(idx).setBirthdate(LocalDate.now());
            table.refresh();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Create person list
        ObservableList<Person> list = FXCollections.observableArrayList();
        list.add(new Person(1, "Jade", "Smith", "js@js.com", LocalDate.of(1989, 9,14)));
        list.add(new Person(2, "John", "Smith", "jhns@jhns.com", LocalDate.of(1989, 9,14)));
        list.add(new Person(3, "James", "Symons", "jsy@jsy.com", LocalDate.of(1989, 6,19)));
        //Link person list with table
        table.setItems(list);
        //Link id with idCol
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        //Link name with nameCol
        numeCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        //Link surname with surnameCol
        prenumeCol.setCellValueFactory(new PropertyValueFactory<>("surname"));
        //Link birthdate with birthdateCol
        dataCol.setCellValueFactory(new PropertyValueFactory<>("birthdate"));
        //Link email with emailCol
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
    }
}

